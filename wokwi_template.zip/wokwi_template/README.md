1. vscode 要安裝 Wokwi Simulator 及 PlatformIO IDE。
2. diagram.json 要從 wokwi 網站上的 diagram.json 下載後貼上。
3. vscode 安裝  Wokwi Simulator後，開啟 diagram.json 後會自動執行 wokwi 的模擬畫面。
   a. 如要修改接線，要先將 diagram.json 改名。如改成 diagram1.json 就可以修改內容貼上了。再將檔名改回就行。
   b. 第一次執行，會要 wokwi 的 License。 請照彈出的要求操作。
4. 程式放在 src/main.ino 中。
